<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Uzivatel extends Model
{
    public $incrementing = false;
    protected $table = 'uzivatel';
    public $timestamps = false;

    protected $fillable = [
        'id',
        'vek',
        'pohlavie',
    ];

    public function osoba()
    {
        return $this->belongsTo(Osoba::class, 'id');
    }
}
