import { Head, Link, useForm } from '@inertiajs/react';
import type { SyntheticEvent } from 'react';
import '../../../css/udalost-form.css';

type Miesto = {
    id: number;
    adresa: string;
};

type Kategorie = {
    id: number;
    typ: string;
    rodic_id: number | null;
};

type Vstupne = {
    typ: string;
    cennik: string;
};

type Props = {
    miesta: Miesto[];
    kategorie: Kategorie[];
    dnes: string;
};

export default function Create({
    miesta,
    kategorie,
    dnes,
}: Props) {
    const {
        data,
        setData,
        post,
        processing,
        errors,
    } = useForm({
        oznacenie: '',
        datum_od: dnes,
        cas_od: '',
        datum_do: dnes,
        cas_do: '',
        vedenie_sedenia: '',
        kapacita: '',
        popis: '',
        ikona: '',
        miesto_id: '',
        kategoria_id: '',
        vstupne: [] as Vstupne[],
    });

    const {
        data: miestoData,
        setData: setMiestoData,
        post: postMiesto,
        processing: miestoProcessing,
        errors: miestoErrors,
        reset: resetMiesto,
    } = useForm({
        adresa: '',
        typ: '',
        popis: '',
    });

    const {
        data: kategoriaData,
        setData: setKategoriaData,
        post: postKategoria,
        processing: kategoriaProcessing,
        errors: kategoriaErrors,
        reset: resetKategoria,
    } = useForm({
        typ: '',
        rodic_id: '',
    });

    function submit(
        event: SyntheticEvent<HTMLFormElement>
    ) {
        event.preventDefault();

        post('/udalosti');
    }

    function submitMiesto(
        event: SyntheticEvent<HTMLFormElement>
    ) {
        event.preventDefault();

        postMiesto('/miesta/navrhnut', {
            preserveScroll: true,

            onSuccess: () => {
                resetMiesto();
            },
        });
    }

    function submitKategoria(
        event: SyntheticEvent<HTMLFormElement>
    ) {
        event.preventDefault();

        postKategoria('/kategorie/navrhnut', {
            preserveScroll: true,

            onSuccess: () => {
                resetKategoria();
            },
        });
    }

    function pridajVstupne() {
        setData('vstupne', [
            ...data.vstupne,
            {
                typ: '',
                cennik: '',
            },
        ]);
    }

    function odstranVstupne(index: number) {
        setData(
            'vstupne',
            data.vstupne.filter(
                (_, currentIndex) => currentIndex !== index
            )
        );
    }

    function zmenVstupne(
        index: number,
        field: keyof Vstupne,
        value: string
    ) {
        const noveVstupne = [...data.vstupne];

        noveVstupne[index] = {
            ...noveVstupne[index],
            [field]: value,
        };

        setData('vstupne', noveVstupne);
    }

    function renderCategoryOptions(
        parentId: number | null,
        level = 0
    ): React.ReactNode[] {
        return kategorie
            .filter(
                (kategoria) =>
                    kategoria.rodic_id === parentId
            )
            .flatMap((kategoria) => [
                <option
                    key={kategoria.id}
                    value={kategoria.id}
                >
                    {'— '.repeat(level)}
                    {kategoria.typ}
                </option>,

                ...renderCategoryOptions(
                    kategoria.id,
                    level + 1
                ),
            ]);
    }

    return (
        <>
            <Head title="Vytvoriť udalosť" />

            <main className="udalost-form-container">
                <div className="udalost-form-header">
                    <div>
                        <Link
                            href="/"
                            className="udalost-form-back"
                        >
                            ← Späť na udalosti
                        </Link>

                        <h1>Vytvoriť udalosť</h1>

                        <p>
                            Vyplňte základné informácie o novej
                            udalosti.
                        </p>
                    </div>
                </div>

                <form
                    className="udalost-form"
                    onSubmit={submit}
                >
                    <section className="udalost-form-section">
                        <h2>Základné informácie</h2>

                        <div className="form-field">
                            <label htmlFor="oznacenie">
                                Označenie udalosti
                            </label>

                            <input
                                id="oznacenie"
                                type="text"
                                value={data.oznacenie}
                                onChange={(event) =>
                                    setData(
                                        'oznacenie',
                                        event.target.value
                                    )
                                }
                                placeholder="Napr. FIT-AI-2026"
                                required
                            />

                            {errors.oznacenie && (
                                <p className="form-error">
                                    {errors.oznacenie}
                                </p>
                            )}
                        </div>

                        <div className="form-field">
                            <label htmlFor="popis">
                                Popis
                            </label>

                            <textarea
                                id="popis"
                                rows={5}
                                value={data.popis}
                                onChange={(event) =>
                                    setData(
                                        'popis',
                                        event.target.value
                                    )
                                }
                                placeholder="Popis udalosti..."
                            />

                            {errors.popis && (
                                <p className="form-error">
                                    {errors.popis}
                                </p>
                            )}
                        </div>
                    </section>

                    <section className="udalost-form-section">
                        <h2>Dátum a čas</h2>

                        <div className="form-grid">
                            <div className="form-field">
                                <label htmlFor="datum_od">
                                    Dátum začiatku
                                </label>

                                <input
                                    id="datum_od"
                                    type="date"
                                    min={dnes}
                                    value={data.datum_od}
                                    onChange={(event) =>
                                        setData(
                                            'datum_od',
                                            event.target.value
                                        )
                                    }
                                    required
                                />

                                {errors.datum_od && (
                                    <p className="form-error">
                                        {errors.datum_od}
                                    </p>
                                )}
                            </div>

                            <div className="form-field">
                                <label htmlFor="cas_od">
                                    Čas začiatku
                                </label>

                                <input
                                    id="cas_od"
                                    type="time"
                                    value={data.cas_od}
                                    onChange={(event) =>
                                        setData(
                                            'cas_od',
                                            event.target.value
                                        )
                                    }
                                    required
                                />

                                {errors.cas_od && (
                                    <p className="form-error">
                                        {errors.cas_od}
                                    </p>
                                )}
                            </div>

                            <div className="form-field">
                                <label htmlFor="datum_do">
                                    Dátum konca
                                </label>

                                <input
                                    id="datum_do"
                                    type="date"
                                    min={data.datum_od || dnes}
                                    value={data.datum_do}
                                    onChange={(event) =>
                                        setData(
                                            'datum_do',
                                            event.target.value
                                        )
                                    }
                                    required
                                />

                                {errors.datum_do && (
                                    <p className="form-error">
                                        {errors.datum_do}
                                    </p>
                                )}
                            </div>

                            <div className="form-field">
                                <label htmlFor="cas_do">
                                    Čas konca
                                </label>

                                <input
                                    id="cas_do"
                                    type="time"
                                    value={data.cas_do}
                                    onChange={(event) =>
                                        setData(
                                            'cas_do',
                                            event.target.value
                                        )
                                    }
                                    required
                                />

                                {errors.cas_do && (
                                    <p className="form-error">
                                        {errors.cas_do}
                                    </p>
                                )}
                            </div>
                        </div>
                    </section>

                    <section className="udalost-form-section">
                        <h2>Miesto a kategória</h2>

                        <div className="form-grid">
                            <div className="form-field">
                                <label htmlFor="miesto_id">
                                    Miesto
                                </label>

                                <select
                                    id="miesto_id"
                                    value={data.miesto_id}
                                    onChange={(event) =>
                                        setData(
                                            'miesto_id',
                                            event.target.value
                                        )
                                    }
                                    required
                                >
                                    <option value="">
                                        Vyber miesto
                                    </option>

                                    {miesta.map((miesto) => (
                                        <option
                                            key={miesto.id}
                                            value={miesto.id}
                                        >
                                            {miesto.adresa}
                                        </option>
                                    ))}
                                </select>

                                {errors.miesto_id && (
                                    <p className="form-error">
                                        {errors.miesto_id}
                                    </p>
                                )}
                            </div>

                            <div className="form-field">
                                <label htmlFor="kategoria_id">
                                    Kategória
                                </label>

                                <select
                                    id="kategoria_id"
                                    value={data.kategoria_id}
                                    onChange={(event) =>
                                        setData(
                                            'kategoria_id',
                                            event.target.value
                                        )
                                    }
                                    required
                                >
                                    <option value="">
                                        Vyber kategóriu
                                    </option>

                                    {renderCategoryOptions(null)}
                                </select>

                                {errors.kategoria_id && (
                                    <p className="form-error">
                                        {errors.kategoria_id}
                                    </p>
                                )}
                            </div>
                        </div>
                    </section>

                    <section className="udalost-form-section">
                        <h2>Kapacita a ďalšie údaje</h2>

                        <div className="form-grid">
                            <div className="form-field">
                                <label htmlFor="kapacita">
                                    Kapacita
                                </label>

                                <input
                                    id="kapacita"
                                    type="number"
                                    min="1"
                                    value={data.kapacita}
                                    onChange={(event) =>
                                        setData(
                                            'kapacita',
                                            event.target.value
                                        )
                                    }
                                    placeholder="Prázdne = neobmedzená"
                                />

                                <span className="form-help">
                                    Ak pole necháš prázdne,
                                    kapacita bude neobmedzená.
                                </span>

                                {errors.kapacita && (
                                    <p className="form-error">
                                        {errors.kapacita}
                                    </p>
                                )}
                            </div>

                            <div className="form-field">
                                <label htmlFor="vedenie_sedenia">
                                    Vedenie sedenia
                                </label>

                                <input
                                    id="vedenie_sedenia"
                                    type="text"
                                    value={data.vedenie_sedenia}
                                    onChange={(event) =>
                                        setData(
                                            'vedenie_sedenia',
                                            event.target.value
                                        )
                                    }
                                    placeholder="Nepovinné"
                                />

                                {errors.vedenie_sedenia && (
                                    <p className="form-error">
                                        {errors.vedenie_sedenia}
                                    </p>
                                )}
                            </div>
                        </div>

                        <div className="form-field">
                            <label htmlFor="ikona">
                                Ikona
                            </label>

                            <input
                                id="ikona"
                                type="text"
                                value={data.ikona}
                                onChange={(event) =>
                                    setData(
                                        'ikona',
                                        event.target.value
                                    )
                                }
                                placeholder="URL alebo cesta k ikone"
                            />

                            {errors.ikona && (
                                <p className="form-error">
                                    {errors.ikona}
                                </p>
                            )}
                        </div>
                    </section>

                    <section className="udalost-form-section">
                        <div className="vstupne-header">
                            <div>
                                <h2>Vstupné</h2>
                            </div>

                            <button
                                type="button"
                                className="secondary-button"
                                onClick={pridajVstupne}
                            >
                                + Pridať vstupné
                            </button>
                        </div>

                        {data.vstupne.length === 0 ? (
                            <p className="vstupne-empty">
                                Zatiaľ nebol pridaný žiadny typ
                                vstupného.
                            </p>
                        ) : (
                            <div className="vstupne-list">
                                {data.vstupne.map(
                                    (vstup, index) => (
                                        <div
                                            className="vstupne-row"
                                            key={index}
                                        >
                                            <div className="form-field">
                                                <label>
                                                    Typ vstupného
                                                </label>

                                                <input
                                                    type="text"
                                                    value={
                                                        vstup.typ
                                                    }
                                                    onChange={(
                                                        event
                                                    ) =>
                                                        zmenVstupne(
                                                            index,
                                                            'typ',
                                                            event
                                                                .target
                                                                .value
                                                        )
                                                    }
                                                    placeholder="Študent"
                                                    required
                                                />

                                                {errors[
                                                    `vstupne.${index}.typ`
                                                ] && (
                                                    <p className="form-error">
                                                        {
                                                            errors[
                                                                `vstupne.${index}.typ`
                                                            ]
                                                        }
                                                    </p>
                                                )}
                                            </div>

                                            <div className="form-field">
                                                <label>
                                                    Cena (€)
                                                </label>

                                                <input
                                                    type="number"
                                                    min="0"
                                                    step="0.01"
                                                    value={
                                                        vstup.cennik
                                                    }
                                                    onChange={(
                                                        event
                                                    ) =>
                                                        zmenVstupne(
                                                            index,
                                                            'cennik',
                                                            event
                                                                .target
                                                                .value
                                                        )
                                                    }
                                                    placeholder="0.00"
                                                    required
                                                />

                                                {errors[
                                                    `vstupne.${index}.cennik`
                                                ] && (
                                                    <p className="form-error">
                                                        {
                                                            errors[
                                                                `vstupne.${index}.cennik`
                                                            ]
                                                        }
                                                    </p>
                                                )}
                                            </div>

                                            <button
                                                type="button"
                                                className="remove-button"
                                                onClick={() =>
                                                    odstranVstupne(
                                                        index
                                                    )
                                                }
                                            >
                                                Odstrániť
                                            </button>
                                        </div>
                                    )
                                )}
                            </div>
                        )}
                    </section>

                    <div className="udalost-form-actions">
                        <Link
                            href="/"
                            className="cancel-button"
                        >
                            Zrušiť
                        </Link>

                        <button
                            type="submit"
                            className="submit-button"
                            disabled={processing}
                        >
                            {processing
                                ? 'Ukladá sa...'
                                : 'Vytvoriť udalosť'}
                        </button>
                    </div>
                </form>

                <details className="navrh-container">
                    <summary>
                        Nenašli ste miesto? Navrhnúť nové miesto
                    </summary>

                    <form
                        className="navrh-form"
                        onSubmit={submitMiesto}
                    >
                        <h2>Navrhnúť nové miesto</h2>
                        <div className="form-field">
                            <label htmlFor="navrh-adresa">
                                Adresa
                            </label>

                            <input
                                id="navrh-adresa"
                                type="text"
                                value={miestoData.adresa}
                                onChange={(event) =>
                                    setMiestoData(
                                        'adresa',
                                        event.target.value
                                    )
                                }
                                placeholder="Napr. Božetěchova 2, Brno"
                                required
                            />

                            {miestoErrors.adresa && (
                                <p className="form-error">
                                    {miestoErrors.adresa}
                                </p>
                            )}
                        </div>

                        <div className="form-field">
                            <label htmlFor="navrh-typ">
                                Typ miesta
                            </label>

                            <input
                                id="navrh-typ"
                                type="text"
                                value={miestoData.typ}
                                onChange={(event) =>
                                    setMiestoData(
                                        'typ',
                                        event.target.value
                                    )
                                }
                                placeholder="Napr. univerzita, hala, klub"
                                required
                            />

                            {miestoErrors.typ && (
                                <p className="form-error">
                                    {miestoErrors.typ}
                                </p>
                            )}
                        </div>

                        <div className="form-field">
                            <label htmlFor="navrh-popis">
                                Popis
                            </label>

                            <textarea
                                id="navrh-popis"
                                rows={4}
                                value={miestoData.popis}
                                onChange={(event) =>
                                    setMiestoData(
                                        'popis',
                                        event.target.value
                                    )
                                }
                                placeholder="Voliteľný popis miesta..."
                            />

                            {miestoErrors.popis && (
                                <p className="form-error">
                                    {miestoErrors.popis}
                                </p>
                            )}
                        </div>

                        <div className="navrh-actions">
                            <button
                                type="submit"
                                className="submit-button"
                                disabled={miestoProcessing}
                            >
                                {miestoProcessing
                                    ? 'Odosielam...'
                                    : 'Navrhnúť miesto'}
                            </button>
                        </div>
                    </form>
                </details>

                <details className="navrh-container">
                    <summary>
                        Nenašli ste kategóriu? Navrhnúť novú kategóriu
                    </summary>

                    <form
                        className="navrh-form"
                        onSubmit={submitKategoria}
                    >
                        <h2>Navrhnúť novú kategóriu</h2>
                        
                        <div className="form-field">
                            <label htmlFor="navrh-kategoria-typ">
                                Názov kategórie
                            </label>

                            <input
                                id="navrh-kategoria-typ"
                                type="text"
                                value={kategoriaData.typ}
                                onChange={(event) =>
                                    setKategoriaData(
                                        'typ',
                                        event.target.value
                                    )
                                }
                                placeholder="Napr. Workshop"
                                required
                            />

                            {kategoriaErrors.typ && (
                                <p className="form-error">
                                    {kategoriaErrors.typ}
                                </p>
                            )}
                        </div>

                        <div className="form-field">
                            <label htmlFor="navrh-rodic-id">
                                Rodičovská kategória
                            </label>

                            <select
                                id="navrh-rodic-id"
                                value={kategoriaData.rodic_id}
                                onChange={(event) =>
                                    setKategoriaData(
                                        'rodic_id',
                                        event.target.value
                                    )
                                }
                            >
                                <option value="">
                                    Bez rodičovskej kategórie
                                </option>

                                {renderCategoryOptions(null)}
                            </select>

                            {kategoriaErrors.rodic_id && (
                                <p className="form-error">
                                    {kategoriaErrors.rodic_id}
                                </p>
                            )}
                        </div>

                        <div className="navrh-actions">
                            <button
                                type="submit"
                                className="submit-button"
                                disabled={kategoriaProcessing}
                            >
                                {kategoriaProcessing
                                    ? 'Odosielam...'
                                    : 'Navrhnúť kategóriu'}
                            </button>
                        </div>
                    </form>
                </details>
            </main>
        </>
    );
}